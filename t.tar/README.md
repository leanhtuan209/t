<h1 align="center">T-Tool - Powerful DDoS Script With 9 Methods</h1>
<em><h5 align="center">Programming Language - Python 3</h5></em>

<p align="center">Please Don't Attack government websites.</p>

# Features And Methods

* Layer4

* VSE: UDP Valve Source Engine specific flood
* SYN: TCP SYN flood
* TCP: TCP junk flood
* UDP:  UDP junk flood
* HTTP: HTTP GET request flood

* Layer7

* SOCKET: Slow HTTP/1.1 socket flood
* HTTP1: TLS HTTP/1.1 GET flood
* HTTP2: TLS HTTP/2 GET flood
* CRINGE: Powerful Method Target Maybe die from Cringe

# Installation

* Please use spoofed server for the best experience.

* ```git clone https://github.com/tutithuybi123/T-Tool-beta```
* ```cd T-Tool-beta; sh install.sh```

* Install CentOS

* ```cd T-Tool-beta; sh installCentOS.sh```

[![Hits](https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https://github.com/FDc0d3/F-Toolhit-counter&count_bg=%230BD4FF&title_bg=%23525050&icon=github.svg&icon_color=%23000000&title=Views&edge_flat=true)](https://hits.seeyoufarm.com)

# contact dev
* Facebook: https://www.facebook.com/hoangtrongtuaccmoi

# Donation
No need



